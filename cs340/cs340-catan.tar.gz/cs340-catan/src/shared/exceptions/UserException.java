package shared.exceptions;

/**
 * An exception that occurs when the user has invalid information
 * @author Jordan
 *
 */
public class UserException extends Exception {

}
