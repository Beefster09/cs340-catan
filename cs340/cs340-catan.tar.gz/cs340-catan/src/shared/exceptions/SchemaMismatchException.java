package shared.exceptions;

public class SchemaMismatchException extends Exception {
	
	public SchemaMismatchException(String message) {
		super(message);
	}

}
