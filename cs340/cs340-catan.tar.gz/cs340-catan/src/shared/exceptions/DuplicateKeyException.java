package shared.exceptions;

public class DuplicateKeyException extends Exception {

}
