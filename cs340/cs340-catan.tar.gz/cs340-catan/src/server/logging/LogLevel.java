package server.logging;

public enum LogLevel {
	ALL, SEVERE, WARNING ,INFO, CONFIG, FINE, FINER, FINEST, OFF;
	
	//private final String strValue;
	
	
	//ALL.strValue = "ALL";
}
