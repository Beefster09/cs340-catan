package client.points;

import client.base.*;

/**
 * Interface for the points controller
 */
public interface IPointsController extends IController
{   
	
	// EMPTY
}

